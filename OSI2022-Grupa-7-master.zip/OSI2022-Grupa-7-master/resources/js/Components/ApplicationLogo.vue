<template>
    <img src="/image/image.png">
</template>
