<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/inertia-vue3';

defineProps({
    admin:Object,
    user:Object,
});
</script>

<template>
    <Head title="Iznajmljivanje jedinice" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight"></h2>
        </template>

    </AuthenticatedLayout>
</template>