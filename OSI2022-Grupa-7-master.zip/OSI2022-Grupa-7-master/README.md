Projekat OSI 2022/23, Grupa 7, Sistem iznajmljivanja stambenih jedinica
